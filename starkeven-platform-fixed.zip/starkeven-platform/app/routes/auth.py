import re

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator
from redis.asyncio import Redis
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.concurrency import run_in_threadpool

from ..config import PLAN_LIMITS, TRIAL_CREDITS
from ..db import get_db
from ..models import Organization, User
from ..ratelimit import fixed_window
from ..redis_client import redis_dep
from ..security import create_token, pwd
from ..utils import client_ip

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])
_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")
_DUMMY_HASH = pwd.hash("starkeven-dummy-password")  # constant-time-ish login for unknown emails
LOGIN_MAX_FAILURES = 10
LOGIN_WINDOW_S = 900


def _clean_email(v: str) -> str:
    v = v.strip().lower()
    if len(v) > 254 or not _EMAIL.match(v):
        raise ValueError("Enter a valid email address")
    return v


class RegisterIn(BaseModel):
    email: str
    password: str = Field(min_length=8, max_length=128)
    organization_name: str = Field(default="My Organization", min_length=1, max_length=200)

    @field_validator("email")
    @classmethod
    def _check_email(cls, v: str) -> str:
        return _clean_email(v)


class LoginIn(BaseModel):
    email: str
    password: str = Field(min_length=1, max_length=128)

    @field_validator("email")
    @classmethod
    def _check_email(cls, v: str) -> str:
        return _clean_email(v)


@router.post("/register", status_code=201)
async def register(
    payload: RegisterIn, request: Request,
    db: AsyncSession = Depends(get_db), redis: Redis = Depends(redis_dep),
):
    allowed, retry = await fixed_window(redis, f"register:{client_ip(request)}", 10, 3600)
    if not allowed:
        raise HTTPException(429, "Too many sign-ups from this address", headers={"Retry-After": str(retry)})
    if (await db.execute(select(User.id).where(User.email == payload.email))).first():
        raise HTTPException(409, "Email already registered")
    hashed = await run_in_threadpool(pwd.hash, payload.password)
    org = Organization(
        name=payload.organization_name.strip(), plan_tier="starter",
        credit_balance=TRIAL_CREDITS, rate_limit_per_min=PLAN_LIMITS["starter"],
    )
    db.add(org)
    await db.flush()
    user = User(org_id=org.id, email=payload.email, hashed_password=hashed, role="owner")
    db.add(user)
    try:
        await db.commit()  # org + user in one transaction
    except IntegrityError:
        await db.rollback()
        raise HTTPException(409, "Email already registered")
    return {
        "access_token": create_token(user), "token_type": "bearer",
        "organization_id": org.id, "credits": org.credit_balance,
    }


@router.post("/login")
async def login(
    payload: LoginIn, request: Request,
    db: AsyncSession = Depends(get_db), redis: Redis = Depends(redis_dep),
):
    fail_key = f"loginfail:{client_ip(request)}:{payload.email}"
    if int(await redis.get(fail_key) or 0) >= LOGIN_MAX_FAILURES:
        raise HTTPException(429, "Too many failed attempts. Try again later.",
                            headers={"Retry-After": str(LOGIN_WINDOW_S)})
    user = (await db.execute(select(User).where(User.email == payload.email))).scalar_one_or_none()
    hashed = user.hashed_password if user else _DUMMY_HASH
    ok = await run_in_threadpool(pwd.verify, payload.password, hashed)
    if not (user and ok and user.is_active):
        await fixed_window(redis, fail_key, LOGIN_MAX_FAILURES, LOGIN_WINDOW_S)
        raise HTTPException(401, "Invalid email or password")
    await redis.delete(fail_key)
    return {"access_token": create_token(user), "token_type": "bearer", "organization_id": user.org_id}
