'use client';

import { useState } from 'react';
import type { FormEvent } from 'react';
import Link from 'next/link';
import { authenticate, errMsg, setToken } from '@/lib/api';
import ThemeToggle from '@/components/ThemeToggle';

export default function LoginPage() {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [org, setOrg] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await authenticate(mode, email, password, org);
      setToken(res.access_token);
      window.location.href = '/dashboard';
    } catch (err) {
      setError(errMsg(err));
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6">
      <div className="mb-6 flex items-center justify-between">
        <Link href="/" className="text-xl font-bold text-brand-700 dark:text-brand-400">StarkEven</Link>
        <ThemeToggle />
      </div>
      <form onSubmit={(e) => void submit(e)} className="card space-y-4">
        <h1 className="text-xl font-semibold">{mode === 'login' ? 'Sign in' : 'Create your account'}</h1>
        {mode === 'register' && (
          <input className="input" placeholder="Company name" value={org} onChange={(e) => setOrg(e.target.value)} />
        )}
        <input className="input" type="email" placeholder="Email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <input
          className="input" type="password" placeholder={mode === 'register' ? 'Password (min. 8 characters)' : 'Password'}
          autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required minLength={mode === 'register' ? 8 : 1}
          value={password} onChange={(e) => setPassword(e.target.value)}
        />
        {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 dark:bg-red-950/60 dark:text-red-300">{error}</p>}
        <button className="btn w-full" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account (50 free credits)'}</button>
        <button type="button" className="w-full text-center text-sm text-brand-600 hover:underline dark:text-brand-400" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(null); }}>
          {mode === 'login' ? 'New here? Create an account' : 'Already have an account? Sign in'}
        </button>
      </form>
    </main>
  );
}
