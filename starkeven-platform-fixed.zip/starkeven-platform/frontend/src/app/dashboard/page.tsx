'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { ApiError, clearToken, getMe, getToken } from '@/lib/api';
import type { Me } from '@/lib/api';
import AutopilotPanel from '@/components/AutopilotPanel';
import BillingPanel from '@/components/BillingPanel';
import BulkPanel from '@/components/BulkPanel';
import EnrichPanel from '@/components/EnrichPanel';
import KeysPanel from '@/components/KeysPanel';
import UsagePanel from '@/components/UsagePanel';
import VerifyPanel from '@/components/VerifyPanel';
import ThemeToggle from '@/components/ThemeToggle';

type Tab = 'Autopilot' | 'Enrich' | 'Bulk CSV' | 'Verify' | 'API Keys' | 'Usage' | 'Billing';

const NAV_ITEMS: { id: Tab; label: string; mobileSpan?: string }[] = [
  { id: 'Autopilot', label: 'Autopilot' },
  { id: 'Enrich', label: 'Enrich' },
  { id: 'Bulk CSV', label: 'Bulk CSV' },
  { id: 'Verify', label: 'Verify' },
  { id: 'API Keys', label: 'API Keys' },
  { id: 'Usage', label: 'Usage' },
  { id: 'Billing', label: 'Billing', mobileSpan: 'col-span-3' },
];

function TabIcon({ id }: { id: Tab }) {
  const cls = 'h-4 w-4 shrink-0';
  switch (id) {
    case 'Autopilot':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={cls} aria-hidden="true">
          <circle cx="12" cy="12" r="9" />
          <polygon points="15.5 8.5 13.5 13.5 8.5 15.5 10.5 10.5 15.5 8.5" />
        </svg>
      );
    case 'Enrich':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={cls} aria-hidden="true">
          <circle cx="11" cy="11" r="7" />
          <path d="m20 20-3.5-3.5" />
        </svg>
      );
    case 'Bulk CSV':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={cls} aria-hidden="true">
          <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z" />
          <path d="M14 3v5h5" />
          <path d="M8 13h8M8 17h5" />
        </svg>
      );
    case 'Verify':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={cls} aria-hidden="true">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" />
          <path d="m9 12 2 2 4-4" />
        </svg>
      );
    case 'API Keys':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={cls} aria-hidden="true">
          <circle cx="7.5" cy="15.5" r="4.5" />
          <path d="m21 2-9.6 9.6M15.5 7.5l3 3" />
        </svg>
      );
    case 'Usage':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={cls} aria-hidden="true">
          <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
        </svg>
      );
    case 'Billing':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className={cls} aria-hidden="true">
          <rect x="2" y="5" width="20" height="14" rx="2" />
          <path d="M2 10h20" />
        </svg>
      );
  }
}

export default function Dashboard() {
  const [me, setMe] = useState<Me | null>(null);
  const [tab, setTab] = useState<Tab>('Autopilot');
  const [tick, setTick] = useState(0);

  const refresh = useCallback(async () => {
    try {
      setMe(await getMe());
      setTick((t) => t + 1);
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) {
        clearToken();
        window.location.href = '/login';
      }
    }
  }, []);

  useEffect(() => {
    if (!getToken()) {
      window.location.href = '/login';
      return;
    }
    void refresh();
  }, [refresh]);

  function logout() {
    clearToken();
    window.location.href = '/';
  }

  if (!me) {
    return (
      <div className="min-h-screen bg-[#F5F5F7] p-12 text-center text-sm text-[#6E6E73] dark:bg-[#000000] dark:text-[#8E8E93]">
        Loading workspace…
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F7] text-[#1D1D1F] transition-colors dark:bg-[#000000] dark:text-[#F5F5F7]">
      {/* Minimalist Frosted-Glass Top Bar */}
      <header className="sticky top-0 z-40 h-14 border-b border-black/[0.08] bg-[#F5F5F7]/80 backdrop-blur-xl dark:border-white/[0.08] dark:bg-[#000000]/80">
        <div className="mx-auto flex h-full max-w-5xl items-center justify-between gap-3 px-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <Link
              href="/"
              className="shrink-0 whitespace-nowrap text-[17px] font-semibold tracking-[-0.02em] text-[#1D1D1F] dark:text-[#F5F5F7]"
            >
              StarkEven
            </Link>
            <span className="hidden truncate text-xs text-[#6E6E73] dark:text-[#8E8E93] md:inline">
              {me.name} · {me.rate_limit_per_min}/min
            </span>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              onClick={() => setTab('Billing')}
              title="Manage plan and credits"
              data-testid="dashboard-credit-pill"
              className="inline-flex h-8 items-center rounded-full border border-black/[0.08] bg-white px-3 text-xs font-semibold tabular-nums text-[#1D1D1F] transition hover:bg-black/[0.03] dark:border-white/[0.08] dark:bg-[#1C1C1E] dark:text-[#F5F5F7] dark:hover:bg-[#2C2C2E]"
            >
              {me.credit_balance.toLocaleString()} credits
            </button>
            <ThemeToggle />
            <button
              type="button"
              onClick={logout}
              aria-label="Sign out"
              className="inline-flex h-8 items-center gap-1.5 rounded-full border border-black/[0.08] bg-white px-2.5 text-xs font-medium text-[#1D1D1F] transition hover:bg-black/[0.03] dark:border-white/[0.08] dark:bg-[#1C1C1E] dark:text-[#F5F5F7] dark:hover:bg-[#2C2C2E] sm:px-3"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5" aria-hidden="true">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <polyline points="16 17 21 12 16 7" />
                <line x1="21" y1="12" x2="9" y2="12" />
              </svg>
              <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 pb-16 pt-6 sm:px-6 sm:pt-8">
        {/* Segmented Control Navigation */}
        <nav aria-label="Workspace sections" className="mb-7">
          {/* Mobile 2-row icon + label segmented grid (< 768px) */}
          <div className="grid grid-cols-3 gap-1.5 rounded-2xl border border-black/[0.06] bg-black/[0.05] p-1.5 dark:border-white/[0.08] dark:bg-[#1C1C1E] md:hidden">
            {NAV_ITEMS.map((item) => {
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTab(item.id)}
                  className={`flex items-center justify-center gap-1.5 rounded-xl px-2 py-2.5 text-xs font-medium transition ${
                    item.mobileSpan === 'col-span-3'
                      ? 'col-span-3 flex-row'
                      : 'flex-col'
                  } ${
                    active
                      ? 'bg-white text-[#1D1D1F] shadow-sm dark:bg-[#2C2C2E] dark:text-[#F5F5F7]'
                      : 'text-[#6E6E73] hover:text-[#1D1D1F] dark:text-[#8E8E93] dark:hover:text-[#F5F5F7]'
                  }`}
                >
                  <TabIcon id={item.id} />
                  <span className="whitespace-nowrap">{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Desktop centered Apple Segmented Control pill bar (>= 768px) */}
          <div className="hidden justify-center md:flex">
            <div className="inline-flex items-center gap-1 rounded-full border border-black/[0.06] bg-black/[0.05] p-1 dark:border-white/[0.08] dark:bg-[#1C1C1E]">
              {NAV_ITEMS.map((item) => {
                const active = tab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setTab(item.id)}
                    className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 py-1.5 text-[13px] font-medium transition ${
                      active
                        ? 'bg-white text-[#1D1D1F] shadow-sm dark:bg-[#2C2C2E] dark:text-[#F5F5F7]'
                        : 'text-[#6E6E73] hover:text-[#1D1D1F] dark:text-[#8E8E93] dark:hover:text-[#F5F5F7]'
                    }`}
                  >
                    <TabIcon id={item.id} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </nav>

        <div className="space-y-6">
          {tab === 'Autopilot' && <AutopilotPanel onSpend={refresh} />}
          {tab === 'Enrich' && <EnrichPanel onSpend={() => void refresh()} />}
          {tab === 'Bulk CSV' && <BulkPanel onSpend={() => void refresh()} signingSecret={me.callback_signing_secret} />}
          {tab === 'Verify' && <VerifyPanel onSpend={() => void refresh()} />}
          {tab === 'API Keys' && <KeysPanel />}
          {tab === 'Usage' && <UsagePanel refreshKey={tick} />}
          {tab === 'Billing' && <BillingPanel me={me} onUpdate={refresh} />}
        </div>
      </main>
    </div>
  );
}
